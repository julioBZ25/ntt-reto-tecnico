import Table from "./components/Table/Table";

function App() {
  return (
    <div>
      <Table />
    </div>
  );
}

export default App;
